# 🌌 3D Galaxy Universe Simulator

**Beta 0.1.0** - First Public Release

A stunning 3D galaxy simulator featuring realistic spiral galaxies with branches and clouds, supermassive black holes, stars, and orbiting planets. Navigate through space and click on objects to view detailed information.

![Free to Play](https://img.shields.io/badge/Free%20to%20Play-Yes-brightgreen)
![Platform](https://img.shields.io/badge/Platform-Windows-blue)
![Version](https://img.shields.io/badge/Version-Beta%200.1.0-orange)
![License](https://img.shields.io/badge/License-Proprietary-red)

## Features

### Galaxy System
- **Spiral Galaxies**: Realistic spiral galaxies with 2-6 spiral arms
- **Galaxy Branches**: Procedurally generated spiral arms with star clouds
- **Hierarchical Loading**: Galaxies load their stars only when you approach them (saves FPS!)
- **Dynamic LOD**: Distant galaxies appear as glowing spirals, close galaxies show individual stars
- **Supermassive Black Holes**: Every galaxy has a black hole at its center
- **Black Hole Rendering**: 
  - Event horizon (pure black sphere)
  - Accretion disk (orange/yellow swirling matter)
  - Gravitational lensing effect (bright ring)
- **Galaxy Colors**: Blue-white, yellow-white, and red-white galaxy variations
- **Massive Scale**: Galaxies span 2000-5000 units in radius

### Interactive Info System
- **Click on Galaxies**: View branch count, star count, radius, and black hole info
- **Click on Stars**: See star type, radius, and planet counts by type
- **Click on Black Holes**: View event horizon size, accretion disk radius, and location
- **Planet Statistics**: Rocky, Gas, and Ice planet counts for each star
- **Real-time UI**: Info menu follows your clicks and updates dynamically

### Realistic 3D Stars
- **3D Sphere Rendering**: Stars appear as realistic spheres with proper lighting and shading
- **Glowing Corona**: Multi-layered atmospheric glow around each star
- **Surface Texture**: Random variations simulating solar activity and surface detail
- **Bright Core**: White-hot centers for larger stars
- **Solar Prominences**: Flame-like protrusions extending from larger stars
- **Massive Scale**: Stars range from 10-70 units in radius, creating epic celestial bodies
- **Three Star Types**:
  - White stars (45%) - Medium to huge, bright white (10-50 radius)
  - Yellow stars (40%) - Sun-like, golden yellow (15-60 radius)
  - Red giants (15%) - Massive, deep red (30-70 radius)

### Planets
- **Orbital Mechanics**: Planets orbit around their parent stars in real-time
- **Three Planet Categories**:
  - **Rocky Planets**: Mercury, Venus, Mars, Earth (with surface textures and craters)
  - **Gas Giants**: Jupiter, Saturn (with atmospheric bands)
  - **Ice Giants**: Neptune, Uranus, Purple, Green (with cold atmospheric bands)
- **Temperature-Based Coloring**: 
  - Planets close to their star glow red-hot or white-hot
  - Planets far from their star appear blue-white and icy
  - Medium distance planets retain their natural colors
- **Five Size Categories**: Tiny, Small, Normal, Giant, Super Giant (3-46 radius)
- **Rare Earth**: Earth-like planets are extremely rare (0.1% chance!)
- **Dynamic Systems**: 10% of stars have 1-2 orbiting planets
- **Varied Orbits**: Planets orbit at different distances and speeds
- **Realistic Physics**: Closer planets orbit faster, distant planets orbit slower

### Camera System
- **Free-look Mouse Control**: Move your mouse to look around in any direction
- **6-Axis Movement**: Full freedom to navigate through 3D space
- **Speed Boost**: Hold Shift for faster movement
- **Smooth Rotation**: Responsive camera controls with adjustable sensitivity

### Dynamic Universe
- **Hierarchical Rendering**: Galaxies → Stars → Planets (performance optimized!)
- **Smart Loading**: Stars only load when you approach a galaxy (within 8000 units)
- **Auto Unloading**: Stars unload when you move away (beyond 12000 units)
- **Depth-based Rendering**: Objects fade with distance for realistic depth perception
- **Depth Buffer Occlusion**: Objects behind other objects are properly hidden
- **Massive Scale**: Universe spans 60000x40000x100000 units
- **30 Galaxies**: Each with 300-800 stars
- **Optimized Culling**: Only visible objects are rendered for better performance

## Build Versions

This project supports two build configurations:

### DEV Version (Testing)
- **Current Mode**: Active by default
- **Features**:
  - Debug information displayed (star count, FPS, speed)
  - Massive spawn area (6000x4000x10000 units)
  - More stars (2000 initial, up to 5000 max)
  - Performance stats available
  - Extended testing parameters

### PUBLIC Version (Release)
- **Features**:
  - Clean UI with minimal info
  - Large spawn area (4000x3000x8000 units)
  - Balanced star count (1000 initial, up to 3000 max)
  - Production-ready settings

## Switching Between Versions

To switch from DEV to PUBLIC version:

1. Open `Config.cs`
2. Change line 8 from:
   ```csharp
   public const bool IS_DEV_BUILD = true;
   ```
   to:
   ```csharp
   public const bool IS_DEV_BUILD = false;
   ```
3. Rebuild the project

## Controls

### Main Menu
- **Mouse**: Hover over buttons to select
- **Arrow Up/Down**: Navigate between PLAY and EXIT
- **Enter or Left Click**: Confirm selection
- **PLAY**: Start the simulation
- **EXIT**: Quit the application (only way to exit)

### In-Game Controls

#### Camera Movement
- **W**: Move forward (into space)
- **S**: Move backward
- **A**: Strafe left
- **D**: Strafe right
- **Arrow Up**: Move up
- **Arrow Down**: Move down
- **Arrow Left**: Strafe left
- **Arrow Right**: Strafe right

#### Camera Look
- **Mouse Movement**: Look around in any direction (always active)
- **Mouse Wheel (Molette)**: Scroll up to increase speed, scroll down to decrease speed (1-50 range)

#### Interaction
- **Left Click**: Click on galaxies, stars, or black holes to view info
- **Right Click or Escape**: Close info menu

#### Other
- **Left Shift**: Hold to move 2x faster (multiplies current speed)
- **Right Shift (Maj Droit)**: Return to main menu
- **Print Screen**: Take a screenshot (saved to Screenshots folder)

## Running the Project

### Prerequisites
- .NET 6.0 or higher
- MonoGame Framework

### Setup and Run

First, restore packages:
```bash
dotnet restore
```

Then build and run:
```bash
dotnet build
dotnet run
```

The game will launch in fullscreen mode at your native resolution.

## Technical Details

### Rendering
- **Engine**: MonoGame Framework
- **Graphics**: Custom pixel-based rendering with procedural star generation
- **Display**: Fullscreen, native resolution
- **Star Rendering**: Multi-layer corona, 3D sphere shading, procedural surface detail

### Performance
- Optimized depth sorting for stars and planets
- Depth buffer for proper occlusion culling
- Frustum culling for off-screen objects
- Dynamic star spawning and despawning
- Configurable limits (1000-5000 stars, hundreds of planets depending on build)
- Real-time orbital calculations

### Architecture
- `UniverseGame.cs`: Main game loop, rendering, and click handling
- `Galaxy.cs`: Galaxy properties, spiral arm generation, and star loading
- `GalaxySpawner.cs`: Galaxy generation and hierarchical loading system
- `GalaxyRenderer.cs`: Galaxy and black hole rendering
- `BlackHole.cs`: Black hole properties and projection
- `Star.cs`: Star properties, types, and projection
- `StarRenderer.cs`: Advanced 3D star rendering with coronas and flares
- `Planet.cs`: Planet properties, types, and orbital mechanics
- `PlanetRenderer.cs`: Planet rendering with atmospheric effects
- `PlanetSpawner.cs`: Planet generation and orbital system management
- `InfoMenu.cs`: Interactive info menu for clicked objects
- `Camera.cs`: 3D camera with rotation and movement
- `MainMenu.cs`: Menu system with keyboard and mouse support
- `Config.cs`: Build configuration and parameters

## Customization

You can adjust various parameters in `Config.cs`:
- Star count limits
- Spawn area dimensions
- Star spawn rate
- Debug information display
- And more...

## Future Enhancements
- Nebula clouds between galaxies
- Moons orbiting planets
- Asteroid belts around stars
- Planet rings (Saturn-style)
- Comets with tails
- Galaxy collisions
- Quasars and pulsars
- Warp speed effects
- More detailed planet surfaces
- Space stations
