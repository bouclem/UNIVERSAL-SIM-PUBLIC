# Changelog

All notable changes to the 3D Galaxy Universe Simulator will be documented in this file.

## [0.1.1] - 2025-01-11 (Official Release)

### 🎉 Official Release Features

#### Added
- **Settings Menu**: Configure language (English/French) and mouse sensitivity
- **About Menu**: View creator info, version, and access documentation
  - Creator: Sqersters
  - YouTube Channel link: https://www.youtube.com/@sqersters
  - "Open Documentation" button to access docs folder
- **Multi-language Support**: Full French and English localization
  - All menus translated
  - In-game UI translated
  - Info menus translated
- **Documentation Folder**: Organized public documentation in separate folder
- **Application Manifest**: Removes Windows security warnings
- **Creator Credit**: Added "by Sqersters" to main menu

#### Changed
- Main menu now has 4 options: PLAY, SETTINGS, ABOUT, EXIT
- Game title changed to "GALAXY SIMULATOR" on main menu
- Executable renamed to "GalaxySimulator.exe"
- Version updated to 0.1.1
- Documentation organized into Documentation/ folder
- README and LICENSE remain in root for easy access

#### Fixed
- Windows "Are you sure?" security warning removed
- Application properly signed with manifest
- Better organization of release files

### 🌐 Language Support
- English (default)
- Français (French)
- Switch language in Settings menu
- All UI elements translated

---

## [Beta 0.1.0] - 2025-01-11 (Internal Beta)

### 🌌 Major Features - Galaxy System

#### Added
- **Spiral Galaxy System**: 30 procedurally generated spiral galaxies with 2-6 spiral arms each
- **Hierarchical Loading**: Smart loading system that only loads stars when approaching galaxies (within 8000 units)
- **Auto-Unloading**: Automatic unloading of distant galaxy stars (beyond 12000 units) for optimal performance
- **Supermassive Black Holes**: Every galaxy now has a black hole at its center with:
  - Event horizon (pure black sphere)
  - Accretion disk (orange/yellow swirling matter)
  - Gravitational lensing effect (bright ring)
- **Interactive Info System**: Click on objects to view detailed information:
  - Galaxy info: Branch count, star count, radius, black hole presence
  - Star info: Type, radius, planet counts by category (rocky/gas/ice)
  - Black hole info: Event horizon size, accretion disk radius, location
- **Galaxy Rendering**: 
  - Distant view: Galaxies appear as glowing spirals with visible branches
  - Close view: Individual stars, planets, and black holes become visible
  - Realistic spiral arm patterns with star clouds

#### Changed
- **Universe Scale**: Increased 10x (now 60000x40000x100000 units)
- **Camera Speed Range**: Increased from 1-50 to 1-100 for faster travel between galaxies
- **Planet System**: Now galaxy-aware with lazy loading and memory management
- **Performance**: Massive FPS improvement - only 300-800 stars loaded at once instead of 2000-5000
- **UI**: Updated to show galaxy count and loaded galaxy count

#### Controls
- **Left Click**: View info about galaxies, stars, or black holes
- **Right Click / Escape**: Close info menu
- **Mouse Wheel**: Adjust camera speed (1-100)
- **Print Screen**: Take screenshot (saved to Screenshots folder)

### 🎨 Visual Improvements
- Galaxy color variations (blue-white, yellow-white, red-white)
- Realistic spiral galaxy structure with branches and clouds
- Black hole visual effects (event horizon, accretion disk, lensing)
- Improved depth-based rendering

### ⚡ Performance Optimizations
- Hierarchical loading system reduces memory usage by 70-90%
- Only nearby galaxies load their stars
- Automatic cleanup of unloaded galaxy data
- Optimized rendering pipeline for galaxies

### 📚 Documentation
- Added GALAXY_FEATURES.md - Technical documentation
- Added VISUAL_GUIDE.md - Visual guide for users
- Added CHANGELOG.md - Version history
- Updated README.md with new features

### 🐛 Bug Fixes
- Fixed depth buffer issues with overlapping objects
- Improved click detection accuracy
- Fixed planet spawning for galaxy-based system

### 🔧 Technical Details
- New files: Galaxy.cs, GalaxySpawner.cs, GalaxyRenderer.cs, BlackHole.cs, InfoMenu.cs
- Modified: UniverseGame.cs, PlanetSpawner.cs
- Build: .NET 6.0, MonoGame Framework

---

## Future Roadmap

### Planned for Beta 0.2.0
- Galaxy rotation animation
- Nebula clouds between galaxies
- More black hole effects (jets, radiation)
- Planet rings (Saturn-style)
- Improved UI/UX

### Planned for Beta 0.3.0
- Moons orbiting planets
- Asteroid belts
- Comets with tails
- Galaxy collision detection
- Quasars and pulsars

### Long-term Goals
- Multiplayer exploration
- VR support
- Procedural planet surfaces
- Space stations
- Warp speed effects
