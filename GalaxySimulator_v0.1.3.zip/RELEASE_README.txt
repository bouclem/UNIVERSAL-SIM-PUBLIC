﻿3D Galaxy Universe Simulator - Version 0.1.3
THE GRAVITY UPDATE

DOCUMENTATION:
  README.md - Complete user guide
  CHANGELOG.md - Version history
  docs/ - Additional guides and release notes

Developed by: Sqersters
Engine: MonoGame Framework
Version: 0.1.3
Release Date: 2025
