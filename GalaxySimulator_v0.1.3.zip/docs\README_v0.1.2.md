# Universe Simulator v0.1.2 🌌

## 🎯 Qu'est-ce que c'est?

Un simulateur d'univers 3D interactif avec des galaxies, étoiles, planètes et trous noirs. Explorez l'espace infini avec un contrôle total sur les détails visuels et les performances.

## ✨ Nouveautés v0.1.2

### 🎨 Système de Détail Global à 5 Niveaux

Contrôlez la qualité visuelle de **TOUT** l'univers:

| Niveau | Description | FPS | Usage |
|--------|-------------|-----|-------|
| 🌑 **FAIBLE** | Formes simples, pas d'effets | 200+ | PC faibles |
| ☀️ **NORMAL** | Variations de teinte, lueur simple | 60+ | Usage quotidien |
| 🌟 **OPTIMISÉ** | Textures animées, particules légères | 45+ | PC moyens |
| 🌞 **HAUT** | Effets dynamiques, shaders actifs | 30+ | Bons PC |
| 🌋 **MAX** | Ultra-détaillé, effets volumétriques | 20+ | PC gamers |

### 🚀 Fonctionnalités Principales

- **Univers Massif**: Galaxies 10x plus grandes, étoiles 35x plus grandes
- **Rendu Optimisé**: Seulement une branche de galaxie visible à la fois
- **Settings Complets**: Contrôle total sur tailles, distances, spawn rates
- **3 Presets**: Performance / Balanced / Quality
- **Temps Réel**: Changements instantanés

## 🎮 Contrôles

### Mouvement
- **W/S**: Avant/Arrière
- **A/D**: Gauche/Droite
- **Space**: Monter
- **Left Shift**: Descendre
- **Souris**: Regarder autour
- **Molette**: Ajuster la vitesse

### Actions
- **Clic Gauche**: Sélectionner / Téléporter vers galaxie
- **Clic Droit / Escape**: Fermer menu info
- **Right Shift**: Retour au menu
- **Print Screen**: Screenshot

## ⚙️ Configuration Recommandée

### PC Faible
```
Menu → Settings → Advanced Settings
- Preset: Performance
- Detail Level: LOW
- Max Visible Stars: 100-200
```

### PC Moyen
```
- Preset: Balanced
- Detail Level: NORMAL ou OPTIMIZED
- Max Visible Stars: 300-500
```

### PC Puissant
```
- Preset: Quality
- Detail Level: HIGH ou MAX
- Max Visible Stars: 800-1000
```

## 📊 Paramètres Disponibles

### Limites de Rendu
- Max Visible Stars (100-2000)
- Max Visible Planets (50-1000)
- Max Visible Galaxies (10-200)

### Multiplicateurs de Taille (10-500%)
- Galaxies
- Étoiles
- Planètes
- Trous Noirs

### Multiplicateurs de Distance (10-500%)
- View Distance
- Galaxy Spacing

### Taux de Spawn
- Stars Per Galaxy (100-5000)
- Planet Spawn Chance (0-100%)
- Planets Per Star (1-20)
- Total Galaxies (5-100)

### Niveau de Détail
- **LOW**: Formes simples
- **NORMAL**: Variations de teinte
- **OPTIMIZED**: Animations légères
- **HIGH**: Effets dynamiques
- **MAX**: Ultra-détaillé

## 🎯 Cas d'Usage

### Exploration Rapide
```
- Detail Level: NORMAL
- Camera Speed: 300%
- View Distance: 200%
```

### Visuel Époustouflant
```
- Detail Level: MAX
- All Sizes: 300%
- Max Visible: Maximum
```

### Performance Maximale
```
- Detail Level: LOW
- Max Visible Stars: 100
- Depth Buffer: OFF
```

## 📁 Fichiers Importants

- `GameSettings.cs` - Système de settings
- `DetailLevel.cs` - Niveaux de détail
- `AdvancedSettingsMenu.cs` - Menu avancé
- `StarRenderer.cs` - Rendu des étoiles
- `PlanetRenderer.cs` - Rendu des planètes
- `GalaxyRenderer.cs` - Rendu des galaxies

## 🔧 Développement

### Prérequis
- .NET 6.0+
- MonoGame 3.8+
- Visual Studio 2022 ou VS Code

### Build
```bash
dotnet build
dotnet run
```

## 📝 Changelog

### v0.1.2 (Actuel)
- ✅ Système de détail global à 5 niveaux
- ✅ Optimisation massive du rendu
- ✅ Menu de settings avancé complet
- ✅ Presets de performance
- ✅ Objets 10-35x plus grands
- ✅ Distances 10x plus grandes

### v0.1.1
- Système de galaxies avec branches
- Téléportation vers galaxies
- Menu info pour objets
- Système de planètes orbitales

### v0.1.0
- Version initiale
- Galaxies, étoiles, planètes basiques
- Caméra 3D libre

## 🐛 Problèmes Connus

- Les settings ne persistent pas entre sessions (à venir)
- Certains changements nécessitent un redémarrage
- Pas de LOD dynamique automatique

## 🔮 Roadmap

### v0.1.3
- Sauvegarde des profils
- LOD dynamique basé sur FPS
- Plus d'effets visuels

### v0.2.0
- Système de missions
- Découverte de planètes rares
- Statistiques d'exploration

### v0.3.0
- Mode VR
- Multijoueur
- Éditeur d'univers

## 💡 Astuces

1. **FPS Bas?** → Réduire Detail Level et Max Visible objects
2. **Objets Trop Petits?** → Augmenter Size Multipliers
3. **Exploration Lente?** → Augmenter Camera Speed
4. **Trop d'Objets?** → Réduire Spawn Rates

## 📞 Support

- GitHub Issues: [Lien]
- Discord: [Lien]
- Email: [Email]

## 📜 Licence

MIT License - Libre d'utilisation et modification

---

**Développé avec ❤️ et MonoGame**

🌌 **Explorez l'infini!** 🚀
