# Changelog

All notable changes to the 3D Galaxy Universe Simulator will be documented in this file.

## [0.1.2] - 2025

### 🎨 Added - Global Detail System
- **5-Level Detail System**: LOW / NORMAL / OPTIMIZED / HIGH / MAX
  - Affects all objects: stars, planets, galaxies, black holes
  - Performance range: 20-200+ FPS depending on level
  - Real-time switching between levels
- **Detail Descriptions**:
  - 🌑 LOW: Simple shapes, no effects (200+ FPS)
  - ☀️ NORMAL: Tint variations, simple glow (60+ FPS)
  - 🌟 OPTIMIZED: Animated textures, light particles (45+ FPS)
  - 🌞 HIGH: Detailed surfaces, dynamic effects (30+ FPS)
  - 🌋 MAX: Ultra-detailed, volumetric effects (20+ FPS)

### 🚀 Added - Massive Scale Increase
- Galaxies: 10x bigger (20,000-50,000 radius, was 2,000-5,000)
- Black Holes: 30x bigger (1,000-2,500 radius, was 30-80)
- Stars: 35x bigger (750-5,000 radius, was 20-140)
- Planets: 7-10x bigger (20-450 radius, was 3-46)
- Universe spacing: 10x farther (100x Config multiplier, was 10x)

### ⚡ Added - Performance Optimizations
- **Single Branch Rendering**: Only one galaxy arm visible at a time
  - Reduces rendered objects by 80-90%
  - Massive FPS improvement
- **Configurable Render Limits**:
  - Max visible stars (100-2000, default 500)
  - Max visible planets (50-1000, default 200)
  - Max visible galaxies (10-200, default 50)
- **Smart Culling**: Off-screen objects not rendered
- **Optional Features**: Depth buffer, planet details can be toggled

### ⚙️ Added - Complete Settings System
- **Advanced Settings Menu**: 20+ configurable parameters
- **3 Presets**: Performance / Balanced / Quality
- **Size Multipliers**: Adjust all object sizes (10-500%)
- **Distance Multipliers**: Adjust view distances (10-500%)
- **Spawn Rate Controls**:
  - Stars per galaxy (100-5000)
  - Planet spawn chance (0-100%)
  - Planets per star (1-20)
  - Total galaxies (5-100)
- **Camera Speed Multiplier**: 10-1000%
- **Real-time Updates**: Most settings apply instantly

### 🌍 Added - Multilingual Support
- English and Français languages
- Language selection in settings menu

### 📁 Changed - Documentation Structure
- Reorganized docs into `docs/public/` and `docs/private/`
- Public docs for releases
- Private docs for internal development

### 🔧 Changed - Technical Improvements
- Centralized settings management in `GameSettings.cs`
- Modular detail level system in `DetailLevel.cs`
- Enhanced rendering pipeline with level-based routing
- Improved code organization and maintainability

### 📊 Performance Improvements
- Before: 30-60 FPS on average PC
- After: 20-200+ FPS depending on detail level chosen
- Memory usage reduced by ~40% with culling

---

## [0.1.1] - 2025

### Added
- Galaxy branch system with spiral arms
- Hierarchical loading (stars load when approaching galaxy)
- Click-to-teleport to galaxy branches
- Info menu for galaxies, stars, and black holes
- Planet orbital mechanics
- Temperature-based planet coloring
- Rare Earth-like planets (0.1% chance)

### Changed
- Improved galaxy rendering with spiral patterns
- Enhanced star rendering with 3D sphere effects
- Better camera controls with mouse look

### Fixed
- Performance issues with too many objects
- Depth buffer occlusion problems

---

## [0.1.0] - 2025 - Initial Release

### Added
- Basic 3D universe with galaxies
- Spiral galaxy rendering
- Supermassive black holes at galaxy centers
- Three star types (White, Yellow, Red)
- Basic planet system
- Free-look camera with 6-axis movement
- Main menu system
- Screenshot functionality
- Fullscreen mode

### Features
- 30 galaxies with 300-800 stars each
- Realistic star rendering with glow effects
- Planet types: Rocky, Gas Giants, Ice Giants
- Mouse and keyboard controls
- Dynamic star spawning

---

## Legend

- **Added**: New features
- **Changed**: Changes to existing features
- **Deprecated**: Features that will be removed
- **Removed**: Removed features
- **Fixed**: Bug fixes
- **Security**: Security fixes

## Version Format

This project uses Semantic Versioning: MAJOR.MINOR.PATCH

- **MAJOR**: Incompatible API changes
- **MINOR**: New functionality (backwards compatible)
- **PATCH**: Bug fixes (backwards compatible)
