================================================================================
  3D GALAXY UNIVERSE SIMULATOR - Beta 0.1.0
================================================================================

Thank you for downloading the Galaxy Simulator!

QUICK START
-----------
1. Extract this ZIP file to a folder
2. Run "UniversalSim.exe"
3. Click PLAY in the main menu
4. Use WASD to move, Mouse to look around
5. Left-click on galaxies, stars, or black holes to view info

CONTROLS
--------
Movement:
  WASD / Arrow Keys - Move around
  Space - Move up
  Left Shift - Move down
  Mouse - Look around
  Mouse Wheel - Adjust speed (1-100)

Interaction:
  Left Click - View object info
  Right Click / Escape - Close info menu
  Print Screen - Take screenshot

Menu:
  Right Shift - Return to main menu

WHAT TO EXPLORE
----------------
- 30 Spiral Galaxies with realistic structure
- Supermassive Black Holes at galaxy centers
- Thousands of stars (White, Yellow, Red types)
- Hundreds of planets (Rocky, Gas, Ice types)
- Interactive info system - click to learn!

TIPS
----
1. Start at speed 5-10 to get oriented
2. Look for glowing spiral shapes (galaxies)
3. Approach galaxies - stars will appear
4. Click on objects to learn about them
5. Find the black hole at each galaxy center
6. Use speed 50-100 to travel between galaxies

SYSTEM REQUIREMENTS
-------------------
Minimum:
  - Windows 10 (64-bit)
  - Intel Core i3 or equivalent
  - 4 GB RAM
  - DirectX 11 compatible GPU

Recommended:
  - Windows 10/11 (64-bit)
  - Intel Core i5 or equivalent
  - 8 GB RAM
  - Dedicated GPU with 2GB VRAM

DOCUMENTATION
-------------
For more information, see these files:
  - README.md - Full documentation
  - VISUAL_GUIDE.md - Visual reference with tips
  - GALAXY_FEATURES.md - Technical details
  - INSTALL.md - Installation guide
  - CHANGELOG.md - Version history

TROUBLESHOOTING
---------------
Low FPS?
  - Move away from galaxy clusters
  - Close other applications
  - Update graphics drivers

Game won't start?
  - Make sure .NET 6.0 is installed
  - Try running as administrator
  - Check if DirectX 11 is supported

Controls not working?
  - Make sure game window has focus
  - Try restarting the game

SCREENSHOTS
-----------
Press Print Screen to capture amazing views!
Screenshots are saved to: Screenshots/ folder

FEEDBACK
--------
Found a bug? Have a suggestion?
Visit: https://github.com/yourusername/galaxy-simulator/issues

LICENSE
-------
This software is FREE TO PLAY but NOT OPEN SOURCE.
See LICENSE file for full terms.

You may:
  - Play the game for free
  - Share screenshots

You may NOT:
  - Modify the software
  - Redistribute the software
  - Use for commercial purposes

VERSION INFO
------------
Version: Beta 0.1.0
Release Date: January 11, 2025
Platform: Windows 10/11 (64-bit)

CREDITS
-------
Built with MonoGame Framework
Procedural generation algorithms
Community feedback and testing

Thank you for playing! 🚀✨

================================================================================
