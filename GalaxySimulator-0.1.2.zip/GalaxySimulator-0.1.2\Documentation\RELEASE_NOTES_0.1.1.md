# Release Notes - Version 0.1.1

## 🎉 Official Release!

This is the first official public release of the 3D Galaxy Universe Simulator by **Sqersters**!

## 🆕 What's New in 0.1.1

### New Menus
- **Settings Menu**: Configure your experience
  - Language selection (English/Français)
  - Mouse sensitivity adjustment
- **About Menu**: Learn about the creator
  - Creator: Sqersters
  - YouTube Channel: https://www.youtube.com/@sqersters
  - Version information
  - Quick access to documentation

### Multi-Language Support 🌐
- **English** (default)
- **Français** (French)
- Switch anytime in Settings
- All menus and UI fully translated

### Improved User Experience
- No more Windows security warnings!
- Better organized documentation
- Creator credit on main menu
- Professional application manifest

## 🎮 Features (from Beta 0.1.0)

### Explore the Universe
- **30 Spiral Galaxies** with realistic structure
- **Supermassive Black Holes** at galaxy centers
- **Thousands of Stars** (White, Yellow, Red types)
- **Hundreds of Planets** (Rocky, Gas, Ice types)
- **Interactive Info System** - Click to learn!

### Smart Performance
- **Hierarchical Loading**: Only nearby galaxies load stars
- **70-90% Better FPS**: Compared to loading everything
- **Smooth Exploration**: Navigate without lag

## 🎮 Controls

**Movement**
- WASD / Arrow Keys: Move around
- Space: Move up
- Left Shift: Move down
- Mouse: Look around
- Mouse Wheel: Adjust speed (1-100)

**Interaction**
- Left Click: View object info
- Right Click / Escape: Close info menu
- Print Screen: Take screenshot

**Menu**
- Right Shift: Return to main menu
- Arrow Keys / Mouse: Navigate menus
- Enter / Left Click: Select

## 📋 System Requirements

**Minimum**
- Windows 10 (64-bit)
- Intel Core i3 or equivalent
- 4 GB RAM
- DirectX 11 compatible GPU
- 100 MB storage

**Recommended**
- Windows 10/11 (64-bit)
- Intel Core i5 or equivalent
- 8 GB RAM
- Dedicated GPU with 2GB VRAM
- 200 MB storage

## 📥 Installation

1. Download `GalaxySimulator-0.1.1.zip`
2. Extract to a folder
3. Run `GalaxySimulator.exe`
4. Enjoy exploring!

No installation required - just extract and play!

## 📚 Documentation

Included in the package:
- `README.md` - Quick start guide (root folder)
- `README_FOR_RELEASE.txt` - Quick reference (root folder)
- `LICENSE` - End User License Agreement (root folder)
- `Documentation/` folder with:
  - `VISUAL_GUIDE.md` - Visual reference
  - `GALAXY_FEATURES.md` - Technical details
  - `CHANGELOG.md` - Version history
  - `RELEASE_NOTES.md` - This file
  - `INSTALL.md` - Installation guide

Access documentation anytime from the About menu!

## 🎯 Tips for New Players

1. **Start in Settings**: Choose your language
2. **Find a Galaxy**: Look for glowing spiral shapes
3. **Approach**: Stars appear as you get within 8000 units
4. **Click Everything**: Learn about galaxies, stars, black holes
5. **Find Black Holes**: Every galaxy has one at the center
6. **Speed Up**: Use 50-100 speed to travel between galaxies
7. **Take Screenshots**: Press Print Screen to capture views

## 🐛 Known Issues

- FPS may drop if 3+ galaxies are loaded (move away to fix)
- Earth-like planets are extremely rare (0.1% chance - by design)

## 🔮 Coming Soon

### Version 0.2.0 (Planned)
- Galaxy rotation animation
- Nebula clouds between galaxies
- Enhanced black hole effects
- Planet rings (Saturn-style)
- More visual improvements

## 👤 About the Creator

**Sqersters**
- YouTube: https://www.youtube.com/@sqersters
- Creating space simulators and games
- Passionate about procedural generation

## ⚖️ License

This software is **FREE TO PLAY** but **NOT OPEN SOURCE**.

You may:
- ✅ Play the game for free
- ✅ Share screenshots
- ✅ Share your experience

You may NOT:
- ❌ Modify the software
- ❌ Redistribute the software
- ❌ Use for commercial purposes
- ❌ Reverse engineer the code

See LICENSE file for full terms.

## 🙏 Thank You!

Thank you for downloading and playing the Galaxy Simulator!

**Found a bug?** Report it on GitHub Issues  
**Have a suggestion?** Let me know!  
**Enjoying the game?** Share your screenshots!  

## 📸 Share Your Discoveries

Press Print Screen to capture amazing views!
Tag @sqersters when sharing on social media!

---

**Version**: 0.1.1  
**Release Date**: January 11, 2025  
**Platform**: Windows 10/11 (64-bit)  
**Creator**: Sqersters  
**License**: Proprietary (Free to Play)  

Happy exploring! 🚀✨
