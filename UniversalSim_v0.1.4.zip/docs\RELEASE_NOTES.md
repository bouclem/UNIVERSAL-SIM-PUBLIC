# Release Notes - Beta 0.1.0

## 🌌 Welcome to the Galaxy Universe Simulator!

This is the first public beta release of the 3D Galaxy Universe Simulator. Explore a procedurally generated universe filled with spiral galaxies, supermassive black holes, stars, and orbiting planets!

## 🎮 What's New in Beta 0.1.0

### Major Features

#### 🌀 Spiral Galaxy System
- **30 Galaxies**: Explore 30 unique spiral galaxies spread across massive space
- **Realistic Structure**: Each galaxy has 2-6 spiral arms with star clouds
- **Dynamic Loading**: Stars only appear when you approach (saves FPS!)
- **Beautiful Rendering**: Distant galaxies show as glowing spirals, close-up reveals individual stars

#### ⚫ Supermassive Black Holes
- **One Per Galaxy**: Every galaxy has a black hole at its center
- **Stunning Visuals**: Event horizon, accretion disk, and gravitational lensing effects
- **Interactive**: Click to view detailed information

#### 🖱️ Interactive Info System
- **Click to Learn**: Left-click on any galaxy, star, or black hole
- **Detailed Stats**: View branch counts, star counts, planet types, and more
- **Easy to Use**: Right-click or press Escape to close

#### 🚀 Performance Optimized
- **Smart Loading**: Only nearby galaxies load their stars
- **70-90% Better FPS**: Compared to loading all stars at once
- **Smooth Exploration**: Navigate through space without lag

### What You Can Do

✅ Explore 30 unique spiral galaxies  
✅ Find supermassive black holes at galaxy centers  
✅ Discover stars with different types (White, Yellow, Red)  
✅ Find planets orbiting stars (Rocky, Gas, Ice types)  
✅ Click on objects to learn about them  
✅ Take screenshots of your discoveries  
✅ Navigate freely in 3D space  
✅ Adjust camera speed (1-100) with mouse wheel  

### Controls

**Movement**
- WASD / Arrow Keys: Move around
- Space: Move up
- Left Shift: Move down
- Mouse: Look around
- Mouse Wheel: Adjust speed

**Interaction**
- Left Click: View object info
- Right Click / Escape: Close info menu
- Print Screen: Take screenshot

**Menu**
- Right Shift: Return to main menu
- Arrow Keys / Mouse: Navigate menu
- Enter / Left Click: Select

## 📊 Statistics

- **30 Galaxies** in the universe
- **300-800 Stars** per galaxy (9,000-24,000 total)
- **2-6 Spiral Arms** per galaxy
- **30 Black Holes** (one per galaxy)
- **Hundreds of Planets** orbiting stars
- **0.1% Chance** of finding Earth-like planets!

## 🎯 Tips for First-Time Explorers

1. **Start Slow**: Begin at speed 5-10 to get oriented
2. **Find a Galaxy**: Look for glowing spiral shapes
3. **Approach**: Stars will appear as you get within 8000 units
4. **Click Everything**: Learn about galaxies, stars, and black holes
5. **Find the Black Hole**: Every galaxy has one at the center
6. **Speed Up**: Use speed 50-100 to travel between galaxies
7. **Watch FPS**: If it drops, move away from galaxy clusters

## 🐛 Known Issues

- Nullable warnings in build (cosmetic, doesn't affect gameplay)
- Very rare Earth-like planets (by design - 0.1% chance)
- FPS may drop if 3+ galaxies are loaded simultaneously (move away to fix)

## 🔮 Coming Soon

### Beta 0.2.0 (Planned)
- Galaxy rotation animation
- Nebula clouds between galaxies
- Enhanced black hole effects
- Planet rings (Saturn-style)
- Improved UI/UX

### Beta 0.3.0 (Planned)
- Moons orbiting planets
- Asteroid belts
- Comets with tails
- Galaxy collisions
- Quasars and pulsars

## 📋 System Requirements

**Minimum**
- Windows 10 (64-bit)
- Intel Core i3 or equivalent
- 4 GB RAM
- DirectX 11 compatible GPU
- 100 MB storage

**Recommended**
- Windows 10/11 (64-bit)
- Intel Core i5 or equivalent
- 8 GB RAM
- Dedicated GPU with 2GB VRAM
- 200 MB storage

## 📦 What's Included

- UniversalSim.exe (Main executable)
- All required DLLs
- README.md (Quick start guide)
- VISUAL_GUIDE.md (Visual reference)
- GALAXY_FEATURES.md (Technical details)
- CHANGELOG.md (Version history)
- LICENSE (MIT License)

## 🙏 Thank You!

Thank you for trying the Beta 0.1.0 release! This is the first public version, and your feedback is invaluable.

**Found a bug?** Report it on GitHub Issues  
**Have a suggestion?** Let us know!  
**Enjoying the simulator?** Share your screenshots!  

## 📸 Share Your Discoveries

Press Print Screen to capture amazing views and share them with the community!

---

**Version**: Beta 0.1.0  
**Release Date**: January 11, 2025  
**Build**: .NET 6.0 / MonoGame  
**License**: Proprietary (Free to Play)  

Happy exploring! 🚀✨
