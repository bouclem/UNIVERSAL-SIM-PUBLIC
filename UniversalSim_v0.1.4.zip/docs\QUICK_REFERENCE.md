# Quick Reference Card

## Game Controls

### Movement
- **W/S**: Forward/Backward (2x speed)
- **A/D**: Strafe Left/Right
- **Space**: Move Up
- **Left Shift**: Move Down
- **Mouse**: Look around (always active)
- **Scroll Wheel**: Adjust speed (10-5000)

### Actions
- **Left Click**: Select object / Teleport to galaxy
- **Right Click / Escape**: Close info menu
- **Right Shift**: Return to main menu
- **Print Screen**: Take screenshot

## Settings Access

```
Main Menu
  └─ Settings
      ├─ Language (English/Français)
      ├─ Mouse Sensitivity
      └─ Advanced Settings
          ├─ Presets (Performance/Balanced/Quality)
          ├─ Rendering Limits
          ├─ Size Multipliers
          ├─ Distance Multipliers
          ├─ Spawn Rates
          ├─ Performance Toggles
          └─ Camera Speed
```

## Quick Presets

### Performance (Low-End Systems)
- 200 max stars, 50 max planets
- Simplified rendering
- Reduced spawn rates

### Balanced (Default)
- 500 max stars, 200 max planets
- Full rendering features
- Standard spawn rates

### Quality (High-End Systems)
- 1000 max stars, 500 max planets
- All features enabled
- Increased spawn rates

## Common Adjustments

### Improve FPS
1. Advanced Settings → Performance Preset
2. Reduce Max Visible Stars to 100-200
3. Disable Depth Buffer, Star Glow, Planet Details

### Bigger Objects
1. Advanced Settings
2. Set all Size Multipliers to 200-300%

### Faster Exploration
1. Advanced Settings
2. Set Camera Speed to 300-500%
3. Set View Distance to 200%

### More Content
1. Advanced Settings
2. Increase Stars Per Galaxy Max to 2000+
3. Increase Planet Spawn Chance to 50%
4. Increase Total Galaxies to 50+

## Default Values

| Setting | Value |
|---------|-------|
| Max Visible Stars | 500 |
| Max Visible Planets | 200 |
| Galaxy Size | 100% (20k-50k) |
| Star Size | 100% (750-5k) |
| Planet Size | 100% (20-450) |
| View Distance | 100% (30k-150k) |
| Stars Per Galaxy | 500-1200 |
| Planet Spawn Chance | 25% |
| Camera Speed | 100% |

## Troubleshooting

### Low FPS
→ Use Performance Preset
→ Reduce Max Visible objects
→ Disable rendering features

### Objects Too Small
→ Increase Size Multipliers
→ Get closer to objects
→ Increase Camera Speed

### Can't Find Galaxies
→ Increase Camera Speed
→ Reduce Galaxy Spacing
→ Increase Total Galaxies

### Too Many Objects
→ Reduce Stars Per Galaxy
→ Reduce Planet Spawn Chance
→ Reduce Max Visible limits

## Tips

- **One branch at a time**: Only one spiral arm is visible when inside a galaxy
- **Click galaxies**: Clicking a galaxy teleports you to a random branch
- **Scroll for speed**: Use mouse wheel to adjust movement speed on the fly
- **Presets are instant**: Try different presets to find your preference
- **Settings persist**: Settings stay active during your session
