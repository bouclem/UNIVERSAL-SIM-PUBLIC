===============================================
       UNIVERSAL SIM v0.1.8
       Explore the Universe
===============================================

WHAT'S NEW IN 0.1.8:
- Major code refactoring and optimization
- New LOD (Level of Detail) rendering system
- Improved performance with spatial hashing
- Better organized project structure
- New rendering presets (Performance, Balanced, Quality, Ultra)
- Optimized math utilities with caching
- Object pooling to reduce memory allocations

CONTROLS:
- WASD / Arrow Keys: Move camera
- Mouse: Look around (when enabled)
- Tab: Toggle mouse look mode
- Space: Move up
- Left Shift: Move down
- Scroll Wheel: Adjust speed
- F11: Toggle fullscreen
- F12: Screenshot (saved to Screenshots folder)
- Right Shift: Return to menu
- Escape: Close info panel
- Left Click: Select object for info

REQUIREMENTS:
- Windows 10/11 (64-bit)
- OpenGL 3.0+ compatible graphics

HOW TO RUN:
Double-click UniversalSim.exe

TIPS:
- Use scroll wheel to adjust camera speed for vast distances
- Press Tab to toggle between exploration and UI mode
- Click on stars, planets, and galaxies for information
- Adjust quality in Settings > Advanced Settings

===============================================
       Created by Sqersters
       https://github.com/Sqersters
===============================================
