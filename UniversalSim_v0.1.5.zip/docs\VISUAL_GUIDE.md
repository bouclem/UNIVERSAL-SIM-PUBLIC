# Visual Guide - Galaxy System

## What You'll See

### 1. Distant View (Far from Galaxies)
```
     *  .  *     ⭕ Galaxy 1 (spiral glow)
  *     .    *
              
    ⭕ Galaxy 2           *  .  *
                      
         *  .  *    ⭕ Galaxy 3
```
- Galaxies appear as glowing spirals
- You can see their spiral arms and branches
- Stars are NOT visible yet
- Click on galaxy to see info (branch count, star count)

### 2. Approaching a Galaxy (8000 units away)
```
        ⭕ Galaxy starts loading...
        
    *  *  *  *  *  Stars appearing!
  *  *  *  ⚫  *  *  *  Black hole visible
    *  *  *  *  *
      *  *  *
```
- Stars gradually appear in spiral pattern
- Black hole becomes visible at center
- Galaxy structure becomes clear
- Spiral arms show star clouds

### 3. Inside a Galaxy (Close View)
```
         ⭐ Yellow Star
              🪐 Planet
              
    ⭐ Red Giant
         🪐 Planet
         
  ⚫ BLACK HOLE (center)
  🟠 Accretion Disk
  
         ⭐ White Star
              🪐 Planet
              🪐 Planet
```
- Individual stars clearly visible
- Planets orbiting their stars
- Black hole with accretion disk at center
- Click on any object for info

### 4. Info Menu Examples

#### Galaxy Info Menu
```
┌─────────────────────────┐
│ GALAXY INFO             │
│                         │
│ Branches: 4             │
│ Stars: 523              │
│ Radius: 3421            │
│ Black Hole: Yes (Center)│
└─────────────────────────┘
```

#### Star Info Menu
```
┌─────────────────────────┐
│ STAR INFO               │
│                         │
│ Type: Yellow            │
│ Radius: 45              │
│                         │
│ PLANETS:                │
│ Rocky: 1                │
│ Gas: 0                  │
│ Ice: 1                  │
└─────────────────────────┘
```

#### Black Hole Info Menu
```
┌─────────────────────────┐
│ BLACK HOLE              │
│                         │
│ Supermassive            │
│ Event Horizon: 65       │
│ Accretion Disk: 325     │
│ Location: Galaxy Center │
└─────────────────────────┘
```

## Visual Effects

### Galaxy Rendering
- **Spiral Arms**: 2-6 arms curving outward
- **Star Clouds**: Dense clusters along arms
- **Central Glow**: Bright core at galaxy center
- **Color Variations**: Blue-white, yellow-white, red-white

### Black Hole Rendering
- **Event Horizon**: Pure black circle (nothing escapes)
- **Accretion Disk**: Orange/yellow swirling matter around it
- **Gravitational Lensing**: Bright ring effect (light bending)
- **Particle Effects**: Glowing particles in disk

### Star Rendering (Same as Before)
- **3D Sphere**: Realistic sphere shading
- **Corona**: Multi-layer glow
- **Surface Detail**: Texture variations
- **Solar Flares**: For larger stars

### Planet Rendering (Same as Before)
- **Rocky Planets**: Surface textures, craters
- **Gas Giants**: Atmospheric bands
- **Ice Giants**: Blue-white coloring
- **Orbital Motion**: Real-time orbits

## UI Elements

### Top-Left Panel
```
┌──────────────────┐
│ FPS: 60          │ (Green if 60+, Yellow if 30-60, Red if <30)
│ SPEED: 25.0      │ (Current camera speed)
│ GALAXIES: 30     │ (Total galaxies)
│ LOADED: 2        │ (Galaxies with stars loaded)
└──────────────────┘
```

### Info Menu (Appears on Click)
- Appears near cursor
- Semi-transparent background
- Colored border
- Auto-positions to stay on screen
- Close with Right-Click or Escape

## Performance Indicators

### Good Performance (60+ FPS)
- 1-2 galaxies loaded
- 300-1600 stars visible
- Smooth camera movement
- Instant click response

### Medium Performance (30-60 FPS)
- 2-3 galaxies loaded
- 600-2400 stars visible
- Slight lag possible
- Still playable

### Low Performance (<30 FPS)
- 3+ galaxies loaded (too close together)
- 900+ stars visible
- Move away from galaxy clusters
- System will auto-unload distant galaxies

## Exploration Tips

### Finding Galaxies
1. Look for glowing spiral shapes
2. They're spread across massive space
3. Use high speed (50-100) to travel between them
4. Slow down when approaching (10-20)

### Exploring a Galaxy
1. Approach until stars appear (8000 units)
2. Slow down to 5-10 speed
3. Navigate through star fields
4. Click on objects to learn about them
5. Find the central black hole

### Finding Black Holes
1. Enter a loaded galaxy
2. Look for the center (brightest area)
3. Black hole has orange accretion disk
4. Pure black sphere in the middle
5. Click to view info

### Finding Planets
1. Stars with planets are rare (10%)
2. Look for small colored dots near stars
3. Planets orbit their stars
4. Get close to see them clearly
5. Click star to see planet count

## Color Guide

### Galaxies
- 🔵 Blue-white: Young, hot stars
- 🟡 Yellow-white: Mixed age stars
- 🔴 Red-white: Old, cool stars

### Stars
- ⚪ White: Hot, bright (45%)
- 🟡 Yellow: Sun-like (40%)
- 🔴 Red: Cool giants (15%)

### Planets
- 🟤 Rocky: Mercury, Venus, Mars
- 🔵 Earth: VERY RARE (0.1%)
- 🟠 Gas: Jupiter, Saturn
- 🔷 Ice: Neptune, Uranus, Purple, Green

### Black Holes
- ⚫ Event Horizon: Pure black
- 🟠 Accretion Disk: Orange/yellow
- ⚪ Lensing Ring: Bright white

## Scale Reference

### Distances
- Galaxy Radius: 2000-5000 units
- Galaxy Spacing: 10000-50000 units
- Star Spacing (in galaxy): 100-500 units
- Planet Orbit: 150-950 units from star
- Load Distance: 8000 units
- Unload Distance: 12000 units

### Sizes
- Galaxy: 2000-5000 radius
- Black Hole Event Horizon: 30-80 radius
- Black Hole Accretion Disk: 120-560 radius
- Star: 20-140 radius
- Planet: 3-46 radius

### Camera Speed
- Minimum: 1 (very slow, for close inspection)
- Default: 5 (good for exploring galaxies)
- Medium: 25 (traveling within galaxy)
- High: 50-100 (traveling between galaxies)

## Tips for Best Experience

1. **Start Slow**: Begin at speed 5-10 to get oriented
2. **Find a Galaxy**: Look for glowing spirals
3. **Approach Carefully**: Stars will appear as you get close
4. **Explore Inside**: Navigate through the star field
5. **Click Everything**: Learn about galaxies, stars, black holes
6. **Find the Black Hole**: Every galaxy has one at the center
7. **Look for Planets**: Only 10% of stars have them
8. **Travel Fast**: Use speed 50-100 between galaxies
9. **Watch FPS**: If it drops, move away from galaxy clusters
10. **Take Screenshots**: Press Print Screen to capture views

## Common Questions

**Q: Why can't I see any stars?**
A: You're too far from galaxies. Stars only appear within 8000 units of a galaxy center.

**Q: Where are the black holes?**
A: At the center of each galaxy. You need to be close enough for the galaxy to load.

**Q: Why is my FPS low?**
A: You're near multiple loaded galaxies. Move away and they'll auto-unload.

**Q: How do I find planets?**
A: Click on stars to see if they have planets. Only 10% do.

**Q: What's the rarest thing?**
A: Earth-like planets! Only 0.1% chance (about 1-2 in entire universe).

**Q: Can I destroy black holes?**
A: No, this is a simulator, not a game. Just observe and explore!

**Q: How many galaxies are there?**
A: 30 galaxies, each with 300-800 stars.

**Q: Do galaxies rotate?**
A: Not yet, but it's a planned feature!
