# 🌌 Gravity Update - Quick Start Guide

## Getting Started with Realistic Gravity

### Step 1: Enable Gravity Physics
1. Launch the game
2. Go to **Main Menu** → **Settings** → **Advanced Settings**
3. Find **"REALISTIC GRAVITY"** and toggle it **ON**
4. Press **BACK** to return to game

### Step 2: Adjust Settings (Optional)

#### For Best Performance
- **Gravity Quality**: Set to **1 (Low)**
- **Gravity Speed**: Set to **16** (default)
- Disable **Show Gravity Vectors** and **Show Orbital Paths**

#### For Best Visuals
- **Gravity Quality**: Set to **3 (High)**
- Enable **Show Gravity Vectors** to see forces
- Enable **Show Orbital Paths** to see predicted orbits

### Step 3: Observe the Physics

#### What to Look For:
1. **Elliptical Orbits**: Planets no longer move in perfect circles
2. **Varying Speeds**: Planets move faster when closer to stars
3. **Black Hole Capture**: Get too close and objects are pulled in
4. **Orbital Precession**: Orbits slowly rotate over time

## Controls

| Key | Action |
|-----|--------|
| **W/S** | Move forward/backward |
| **A/D** | Strafe left/right |
| **Space** | Move up |
| **Left Shift** | Move down |
| **Mouse** | Look around |
| **Scroll Wheel** | Adjust camera speed |
| **Right Shift** | Return to menu |

## Understanding the Visualization

### Gravity Vectors (Yellow Arrows)
- **Direction**: Points toward the source of gravity
- **Length**: Indicates force strength
- Longer arrow = stronger gravitational pull

### Orbital Paths (Blue Lines)
- Shows predicted trajectory for next ~64 time steps
- Helps visualize orbital shape
- Updates in real-time

## Tips & Tricks

### 1. Finding Interesting Orbits
- Look for planets close to stars (fast, tight orbits)
- Find planets far from stars (slow, wide orbits)
- Watch for planets near black holes (extreme gravity)

### 2. Performance Optimization
If experiencing low FPS:
1. Lower **Gravity Quality** to 1
2. Disable visualization options
3. Reduce **Max Visible Planets** in Advanced Settings
4. Use **Performance Preset** button

### 3. Comparing Old vs New
Toggle **Realistic Gravity** ON/OFF to see the difference:
- **OFF**: Perfect circular orbits (legacy)
- **ON**: Realistic elliptical orbits (new)

## Common Questions

### Q: Why are orbits not perfect circles?
**A:** Real orbits are elliptical due to gravitational physics. Perfect circles only occur under specific conditions.

### Q: Can planets collide?
**A:** Not in this version, but they can get very close and affect each other's orbits.

### Q: What happens if I fly into a black hole?
**A:** Your camera won't be affected, but planets and stars within the event horizon would be captured.

### Q: Does gravity affect my camera?
**A:** No, the camera is not affected by gravity for gameplay reasons.

### Q: Why do some planets orbit faster than others?
**A:** Orbital velocity depends on distance from the star. Closer planets orbit faster (Kepler's Third Law).

## Troubleshooting

### Issue: Planets moving too fast/slow
**Solution:** Adjust **Gravity Speed** in Advanced Settings
- Lower value = slower motion
- Higher value = faster motion

### Issue: Low FPS with gravity enabled
**Solution:** 
1. Set **Gravity Quality** to 1 (Low)
2. Disable **Show Gravity Vectors** and **Show Orbital Paths**
3. Use **Performance Preset**

### Issue: Can't see gravity effects
**Solution:**
1. Make sure **Realistic Gravity** is **ON**
2. Enable **Show Gravity Vectors** to visualize forces
3. Watch planets for several seconds to see orbital changes

## Advanced: Understanding the Physics

### Gravitational Force Formula
```
F = G × (m₁ × m₂) / r²
```
- Stronger for more massive objects
- Weaker with distance (inverse square law)

### Orbital Velocity Formula
```
v = √(G × M / r)
```
- Faster orbits closer to star
- Slower orbits farther from star

### Escape Velocity Formula
```
v_escape = √(2 × G × M / r)
```
- Speed needed to escape gravity
- Higher for more massive objects

---

**Have fun exploring realistic orbital mechanics!** 🚀
