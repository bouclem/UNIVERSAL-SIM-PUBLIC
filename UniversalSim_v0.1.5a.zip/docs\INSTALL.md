# Installation Guide - Beta 0.1.0

## Quick Start (Windows)

### Option 1: Run Pre-built Release (Recommended)
1. Download `GalaxySimulator-Beta-0.1.0.zip` from the releases page
2. Extract the ZIP file to a folder
3. Run `UniversalSim.exe`
4. Enjoy exploring galaxies!

### Option 2: For Developers Only
**Note**: Source code is not publicly available. This is a proprietary application distributed as freeware.

## System Requirements

### Minimum Requirements
- **OS**: Windows 10 (64-bit)
- **Processor**: Intel Core i3 or equivalent
- **Memory**: 4 GB RAM
- **Graphics**: DirectX 11 compatible GPU
- **Storage**: 100 MB available space
- **Display**: 1280x720 resolution

### Recommended Requirements
- **OS**: Windows 10/11 (64-bit)
- **Processor**: Intel Core i5 or equivalent
- **Memory**: 8 GB RAM
- **Graphics**: Dedicated GPU with 2GB VRAM
- **Storage**: 200 MB available space
- **Display**: 1920x1080 resolution or higher

## First Launch

1. **Main Menu**: You'll see the main menu with PLAY and EXIT options
2. **Controls**: Use arrow keys or mouse to navigate
3. **Start**: Press ENTER or click PLAY to begin
4. **Explore**: Use WASD to move, mouse to look around
5. **Interact**: Left-click on galaxies, stars, or black holes to view info

## Troubleshooting

### Game won't start
- Make sure .NET 6.0 is installed
- Check if your GPU supports DirectX 11
- Try running as administrator

### Low FPS
- Move away from galaxy clusters (multiple loaded galaxies)
- Close other applications
- Update your graphics drivers
- Lower your screen resolution

### Black screen
- Wait a few seconds for initialization
- Check if fullscreen mode is causing issues
- Try Alt+Enter to toggle fullscreen

### Controls not working
- Make sure the game window has focus
- Check if your mouse/keyboard is properly connected
- Try restarting the game

### Screenshots not saving
- Check if Screenshots folder exists in game directory
- Make sure you have write permissions
- Try running as administrator

## Configuration

### Changing Build Mode
Edit `Config.cs` to switch between DEV and PUBLIC modes:
```csharp
public const bool IS_DEV_BUILD = false; // Set to true for DEV mode
```

### Adjusting Performance
In `Config.cs`, you can modify:
- `MaxStars`: Maximum number of stars per galaxy
- `InitialStars`: Starting number of stars
- Universe dimensions (MinX, MaxX, etc.)

## Uninstallation

### Pre-built Release
1. Delete the game folder
2. Delete Screenshots folder (if you want to remove screenshots)

### Source Build
1. Delete the cloned repository folder
2. No registry entries or system files are created

## Support

For issues, questions, or feedback:
- GitHub Issues: [Create an issue](https://github.com/yourusername/galaxy-simulator/issues)
- Documentation: See README.md, VISUAL_GUIDE.md, and GALAXY_FEATURES.md

## Updates

To update to a newer version:
1. Download the new release
2. Extract to a new folder (or overwrite old files)
3. Your screenshots are saved separately and won't be affected

## Credits

- Built with MonoGame Framework
- Procedural generation algorithms
- Community feedback and testing

Thank you for trying the 3D Galaxy Universe Simulator Beta 0.1.0!
