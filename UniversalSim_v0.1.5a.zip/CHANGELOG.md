# Changelog

All notable changes to Universal Sim will be documented in this file.

## [0.1.5] - 2025

### 🎮 Added - Tab Key Toggle
- **Mouse Look Toggle**: Press Tab to toggle mouse look on/off
- **UI Mode**: When mouse look is off, cursor is visible and you can click on objects
- **Camera Mode**: When mouse look is on, cursor is hidden and controls camera
- **Seamless Switching**: Toggle anytime during gameplay with Tab key

### 🪐 Added - Planetary Rings
- **Ring System**: Gas giants can now have Saturn-like rings
- **30% Spawn Rate**: 30% of gas giants (Jupiter, Saturn, Purple, Green) have rings
- **Ring Properties**:
  - Inner radius: 1.3x planet radius
  - Outer radius: 1.8x-2.8x planet radius
  - Thickness: 5% of planet radius
  - Tilt: 0-60 degrees
- **Color Variation**: Yellowish (Saturn), brownish (Jupiter), or icy colors
- **3D Rendering**: Rings rendered as tilted ellipses with proper perspective

### 🌙 Added - Moons
- **Moon Generation**: 40% of Normal+ sized planets have 1-3 moons
- **Realistic Orbits**: Moons orbit at 1.5x-3x planet radius
- **Size Variation**: Moons are 10-30% of parent planet size
- **Orbital Motion**: Moons orbit their parent planets independently
- **Rocky Appearance**: Gray/brown colors like real moons
- **Physics Integration**: Moons have mass and follow orbital mechanics

### ☄️ Added - Asteroid Belts
- **Belt Generation**: 20% of star systems have asteroid belts
- **50-150 Asteroids**: Each belt contains 50-150 small rocky objects
- **Belt Location**: Between 400-700 units from star (between planets)
- **Asteroid Properties**:
  - Size: 1-4 units radius (small rocks)
  - Color: Gray/brown rocky appearance
  - Orbital motion: Each asteroid orbits independently
- **Performance**: Only visible in solar system view

### 🎯 Added - Progressive LOD System
- **Three LOD Levels**:
  1. **Galaxy View**: See galaxy spirals from far away
  2. **Branch View**: Enter galaxy → only stars in that branch render
  3. **Solar System View**: Approach star → only that solar system renders
- **Smart Culling**: Reduces rendered objects by 80-95%
- **Performance Boost**: +40-90% FPS depending on view level
- **Automatic Transitions**: Seamless switching between LOD levels
- **Distance Thresholds**:
  - Solar system view: < 5000 units from star
  - Branch view: < 30000 units from galaxy
  - Galaxy view: > 30000 units from galaxy

### 🚀 Performance Improvements
- **Branch LOD**: Only render stars from current galaxy branch (+40-60% FPS)
- **Solar System LOD**: Only render one solar system when close to star (+70-90% FPS)
- **Smart Planet Filtering**: Planets only render if their star is visible
- **Asteroid Optimization**: Asteroids only render in solar system view

### 📊 Technical Changes
- New classes: `PlanetaryRing`, `Moon`, `Asteroid`, `AsteroidBelt`, `RingRenderer`
- Updated `Planet.cs`: Added `Ring` and `Moons` properties
- Updated `PlanetSpawner.cs`: Added asteroid belt generation
- Updated `GalaxySpawner.cs`: Added `FocusedStar`, `IsInsideSolarSystem`, `ShouldRenderPlanet()`
- Updated `UniverseGame.cs`: Render rings, moons, and asteroids with LOD filtering

---

## [0.1.4] - 2025

### 🧊 Added - Real Ice Planets
- **Four Ice Planet Types**:
  - Ice Blue: Frozen water worlds (like Europa)
  - Ice Cyan: Frozen methane/ammonia worlds (like Enceladus)
  - Ice White: Pure frozen worlds
  - Ice Purple: Exotic frozen compounds
- **Realistic Ice Rendering**:
  - Icy surface textures with cracks and frost patterns
  - Crystal formations and sparkle effects
  - No gas bands - solid frozen surfaces
  - Proper ice density (0.9-1.0)
- **10% Spawn Rate**: Ice planets make up 10% of all planets
- **Physics Integration**: Ice planets work with gravity simulation

### 🌡️ Added - Enhanced Temperature System
- **Distance-Based Coloring**: Planets change appearance based on distance from star
- **Hot Planets**: White-hot and red-orange glow for close planets
- **Cold Planets**: Dark blue and icy appearance for distant planets
- **Realistic Lighting**: Distant planets appear darker (less starlight)
- **Smooth Gradients**: 5 temperature zones with smooth color transitions

### 💾 Added - Settings Persistence
- **Auto-Save**: Settings automatically saved on exit
- **Auto-Load**: Settings loaded on startup
- **Save Location**: `%AppData%/UniversalSim/settings.json`
- **All Settings Saved**: Graphics, camera, gravity, language preferences
- **JSON Format**: Human-readable settings file

### 📊 Added - Dynamic LOD System
- **FPS Monitoring**: Real-time FPS tracking with 60-frame history
- **Auto-Adjust Quality**: Reduces quality when FPS < 30, increases when FPS > 55
- **Smart Adjustments**: Adjusts detail level, object counts, effects in stages
- **Cooldown System**: 3-second cooldown between adjustments
- **Toggle Option**: Can be enabled/disabled in settings

### 🎯 Added - Improved Gravity Visualization
- **Enhanced Gravity Vectors**: Color-coded arrows (yellow to red)
- **Arrowheads**: Clear direction indicators
- **Orbital Path Prediction**: 64-segment trajectory simulation
- **Event Horizon Visualization**: Red circles for black hole danger zones
- **Force Magnitude**: Visual feedback for gravity strength
- **Better Performance**: Optimized rendering

### ✨ Added - Star Luminosity System
- **Realistic Light Physics**: Inverse square law (I = L / 4πr²)
- **Star Luminosity Values**:
  - White stars: 80 luminosity, 1200 light radius
  - Yellow stars: 100 luminosity, 1500 light radius
  - Red giants: 150 luminosity, 2000 light radius
- **Distance-Based Brightness**:
  - Very close (<300): 1.5x brighter
  - Close (300-600): 1.2x brighter
  - Medium (600-900): 1.0x normal
  - Far (900-1200): 0.8x dimmer
  - Very far (>1200): 0.5x minimum
- **Star Color Tinting**: Planets subtly tinted by star's light color
- **Atmospheric Glow**: Enhanced based on star luminosity
- **Light Radius Falloff**: Light doesn't reach infinitely

### Changed
- **Game Renamed**: The game is now officially called "Universal Sim"
- Updated all branding and documentation
- Assembly name changed from GalaxySimulator to UniversalSim
- Removed Neptune and Uranus as gas giants (replaced with true ice planets)
- Enhanced temperature effects with 5 zones instead of 2
- Planet rendering now uses star luminosity for realistic lighting

---

## [0.1.3] - 2025 - THE GRAVITY UPDATE

### 🌌 Added - Realistic N-Body Gravity Simulation
- **Newton's Law of Universal Gravitation**: F = G × (m₁ × m₂) / r²
  - Realistic gravitational forces between all objects
  - Proper mass calculations based on size and density
  - Accurate orbital mechanics with velocity and acceleration
- **Physics System**:
  - PhysicsBody component for all celestial objects
  - Real-time velocity and position updates
  - Gravitational acceleration calculations
  - Collision and event horizon detection
- **Mass Properties**:
  - Stars: Mass based on type (White/Yellow/Red) and radius
  - Planets: Mass based on composition (Rocky/Gas/Ice) and size
  - Black Holes: Supermassive objects with event horizons
  - Realistic density values for different object types

### 🪐 Added - Advanced Orbital Mechanics
- **Orbital Velocity Calculations**: v = √(G × M / r)
  - Planets automatically calculate correct orbital speeds
  - Stable circular and elliptical orbits
  - Proper tangential velocity initialization
- **Escape Velocity**: v_escape = √(2 × G × M / r)
  - Objects can escape gravitational pull with sufficient speed
  - Black holes capture objects within event horizon
- **Schwarzschild Radius**: Event horizon calculations for black holes
  - Objects crossing event horizon are captured
  - Accretion disk gravitational effects
- **Tidal Forces**: Gravitational gradient calculations
  - Stronger near massive objects
  - Affects object stability

### ⚙️ Added - Gravity Settings
- **Enable/Disable Realistic Gravity**: Toggle between physics and simple orbits
- **Simulation Speed**: Adjustable timestep (0.001 - 0.1)
- **Simulation Quality**: Low/Medium/High precision
- **Visualization Options**:
  - Show gravity vectors (force direction and magnitude)
  - Show orbital paths (predicted trajectories)
- **Performance Modes**:
  - Low: Basic gravity, fewer calculations
  - Medium: Standard N-body simulation
  - High: Full precision with all interactions

### 🔬 Technical Improvements
- **GravitySystem.cs**: Core physics engine
  - Gravitational force calculations
  - Orbital mechanics utilities
  - Event horizon and escape velocity functions
- **PhysicsBody.cs**: Physics component system
  - Position, velocity, acceleration tracking
  - Force application and integration
  - Parent-child relationships for orbits
- **Mass-Based Interactions**: All objects have realistic mass
  - Stars: 1000-10000 mass units
  - Planets: 1-100 mass units
  - Black Holes: 100000+ mass units

### 🎮 Gameplay Changes
- Planets now orbit realistically with proper physics
- Black holes exert strong gravitational pull
- Objects can be captured by massive bodies
- More dynamic and unpredictable universe behavior
- Optional: Can disable for classic simple orbits

### 📊 Performance
- Optimized N-body calculations
- Quality settings for performance tuning
- Minimal impact on FPS with medium settings
- High quality mode for powerful systems

---

## [0.1.2] - 2025

### 🎨 Added - Global Detail System
- **5-Level Detail System**: LOW / NORMAL / OPTIMIZED / HIGH / MAX
  - Affects all objects: stars, planets, galaxies, black holes
  - Performance range: 20-200+ FPS depending on level
  - Real-time switching between levels
- **Detail Descriptions**:
  - 🌑 LOW: Simple shapes, no effects (200+ FPS)
  - ☀️ NORMAL: Tint variations, simple glow (60+ FPS)
  - 🌟 OPTIMIZED: Animated textures, light particles (45+ FPS)
  - 🌞 HIGH: Detailed surfaces, dynamic effects (30+ FPS)
  - 🌋 MAX: Ultra-detailed, volumetric effects (20+ FPS)

### 🚀 Added - Massive Scale Increase
- Galaxies: 10x bigger (20,000-50,000 radius, was 2,000-5,000)
- Black Holes: 30x bigger (1,000-2,500 radius, was 30-80)
- Stars: 35x bigger (750-5,000 radius, was 20-140)
- Planets: 7-10x bigger (20-450 radius, was 3-46)
- Universe spacing: 10x farther (100x Config multiplier, was 10x)

### ⚡ Added - Performance Optimizations
- **Single Branch Rendering**: Only one galaxy arm visible at a time
  - Reduces rendered objects by 80-90%
  - Massive FPS improvement
- **Configurable Render Limits**:
  - Max visible stars (100-2000, default 500)
  - Max visible planets (50-1000, default 200)
  - Max visible galaxies (10-200, default 50)
- **Smart Culling**: Off-screen objects not rendered
- **Optional Features**: Depth buffer, planet details can be toggled

### ⚙️ Added - Complete Settings System
- **Advanced Settings Menu**: 20+ configurable parameters
- **3 Presets**: Performance / Balanced / Quality
- **Size Multipliers**: Adjust all object sizes (10-500%)
- **Distance Multipliers**: Adjust view distances (10-500%)
- **Spawn Rate Controls**:
  - Stars per galaxy (100-5000)
  - Planet spawn chance (0-100%)
  - Planets per star (1-20)
  - Total galaxies (5-100)
- **Camera Speed Multiplier**: 10-1000%
- **Real-time Updates**: Most settings apply instantly

### 🌍 Added - Multilingual Support
- English and Français languages
- Language selection in settings menu

### 📁 Changed - Documentation Structure
- Reorganized docs into `docs/public/` and `docs/private/`
- Public docs for releases
- Private docs for internal development

### 🔧 Changed - Technical Improvements
- Centralized settings management in `GameSettings.cs`
- Modular detail level system in `DetailLevel.cs`
- Enhanced rendering pipeline with level-based routing
- Improved code organization and maintainability

### 📊 Performance Improvements
- Before: 30-60 FPS on average PC
- After: 20-200+ FPS depending on detail level chosen
- Memory usage reduced by ~40% with culling

---

## [0.1.1] - 2025

### Added
- Galaxy branch system with spiral arms
- Hierarchical loading (stars load when approaching galaxy)
- Click-to-teleport to galaxy branches
- Info menu for galaxies, stars, and black holes
- Planet orbital mechanics
- Temperature-based planet coloring
- Rare Earth-like planets (0.1% chance)

### Changed
- Improved galaxy rendering with spiral patterns
- Enhanced star rendering with 3D sphere effects
- Better camera controls with mouse look

### Fixed
- Performance issues with too many objects
- Depth buffer occlusion problems

---

## [0.1.0] - 2025 - Initial Release

### Added
- Basic 3D universe with galaxies
- Spiral galaxy rendering
- Supermassive black holes at galaxy centers
- Three star types (White, Yellow, Red)
- Basic planet system
- Free-look camera with 6-axis movement
- Main menu system
- Screenshot functionality
- Fullscreen mode

### Features
- 30 galaxies with 300-800 stars each
- Realistic star rendering with glow effects
- Planet types: Rocky, Gas Giants, Ice Giants
- Mouse and keyboard controls
- Dynamic star spawning

---

## Legend

- **Added**: New features
- **Changed**: Changes to existing features
- **Deprecated**: Features that will be removed
- **Removed**: Removed features
- **Fixed**: Bug fixes
- **Security**: Security fixes

## Version Format

This project uses Semantic Versioning: MAJOR.MINOR.PATCH

- **MAJOR**: Incompatible API changes
- **MINOR**: New functionality (backwards compatible)
- **PATCH**: Bug fixes (backwards compatible)
