# 🌌 Universal Sim

**Version 0.1.5**

A stunning universal simulation featuring **realistic N-body gravity simulation**, massive spiral galaxies, supermassive black holes, giant stars, and orbiting planets. Explore an infinite universe with scientifically accurate gravitational physics and full control over visual quality and performance.

![Free to Play](https://img.shields.io/badge/Free%20to%20Play-Yes-brightgreen)
![Platform](https://img.shields.io/badge/Platform-Windows-blue)
![Version](https://img.shields.io/badge/Version-0.1.5-orange)
![License](https://img.shields.io/badge/License-Proprietary-red)

## 🆕 What's New in v0.1.5

### 🪐 Planetary Rings
Experience **Saturn-like ring systems**:
- **Gas Giant Rings**: 30% of gas giants (Jupiter, Saturn, Purple, Green) have rings
- **Realistic Appearance**: Rings with inner/outer radius, tilt, and thickness
- **Color Variation**: Yellowish (Saturn), brownish (Jupiter), or icy colors
- **3D Rendering**: Rings rendered as tilted ellipses with proper perspective

### 🌙 Moons Orbiting Planets
Planets now have **natural satellites**:
- **Moon Generation**: 40% of Normal+ sized planets have 1-3 moons
- **Realistic Orbits**: Moons orbit at 1.5x-3x planet radius
- **Size Variation**: Moons are 10-30% of parent planet size
- **Rocky Appearance**: Gray/brown colors like real moons

### ☄️ Asteroid Belts
Discover **asteroid fields** between planets:
- **Belt Generation**: 20% of star systems have asteroid belts
- **50-150 Asteroids**: Small rocky objects (1-4 units radius)
- **Orbital Motion**: Asteroids orbit between 400-700 units from star
- **Realistic Colors**: Gray/brown rocky appearance

### 🎯 Progressive LOD System (Performance++)
**Massive performance improvement** with intelligent rendering:
- **Galaxy View**: See galaxy spirals from far away
- **Branch View**: Enter a galaxy branch → only stars in that branch render
- **Solar System View**: Approach a star → only that solar system renders
- **Smart Culling**: Reduces rendered objects by 80-95% depending on view
- **Smooth Transitions**: Automatic switching between LOD levels

### 📊 Performance Impact
- **Branch LOD**: +40-60% FPS (only one branch visible)
- **Solar System LOD**: +70-90% FPS (only one system visible)
- **Overall**: Much smoother experience when exploring

## Previous Updates - v0.1.4

### 🧊 Real Ice Planets Added
Experience **true frozen worlds**:
- **Ice Blue**: Frozen water worlds with blue ice (like Europa)
- **Ice Cyan**: Frozen methane/ammonia worlds with cyan ice (like Enceladus)
- **Ice White**: Pure frozen worlds with white ice
- **Ice Purple**: Exotic frozen compounds with purple ice
- **Realistic Ice Surfaces**: Cracks, frost patterns, and crystal formations
- **Proper Density**: Ice planets have realistic low density (0.9-1.0)
- **Frozen Appearance**: No gas bands - solid icy surfaces with sparkle effects

### 🌡️ Enhanced Temperature System
Planets now change appearance based on distance from their star:
- **Very Close (Hot)**: White-hot glow, molten appearance
- **Close (Warm)**: Red-orange tint, heated surface
- **Medium Distance**: Natural colors maintained
- **Far (Cool)**: Blue-icy tint, cooler appearance
- **Very Far (Cold)**: Dark blue, less illuminated, frozen look

### 💾 Settings Persistence
Your settings are now saved automatically:
- All graphics settings saved
- Camera speed preferences saved
- Gravity simulation settings saved
- Language preference saved
- Settings saved to: `%AppData%/UniversalSim/settings.json`

### 📊 Dynamic LOD System
Automatic quality adjustment based on FPS:
- Monitors FPS in real-time
- Reduces quality when FPS drops below 30
- Increases quality when FPS is stable above 55
- Adjusts detail level, object counts, and effects
- Can be disabled in settings

### 🎯 Improved Gravity Visualization
Enhanced visual feedback for gravity simulation:
- **Gravity Vectors**: Color-coded arrows showing force direction and magnitude
- **Orbital Paths**: Predicted trajectories (64 segments)
- **Event Horizon**: Visual indicator for black hole danger zones
- **Better Colors**: Yellow to red gradient based on force strength
- **Arrowheads**: Clear direction indicators

### ✨ Star Luminosity System
Realistic lighting from stars affects planet appearance:
- **Inverse Square Law**: Light intensity decreases with distance²
- **Star Types**: Different luminosity for White (80), Yellow (100), Red (150)
- **Light Radius**: Stars illuminate up to 1200-2000 units
- **Brightness Multiplier**: Planets closer to stars are brighter (up to 1.5x)
- **Distance Falloff**: Distant planets appear darker (down to 0.5x)
- **Star Color Tint**: Planets subtly tinted by their star's light color
- **Atmospheric Glow**: Enhanced glow effects based on star light

### Game Renamed
- The game is now officially called **Universal Sim**

## Previous Updates - v0.1.3 - THE GRAVITY UPDATE

### 🌌 Realistic N-Body Gravity Simulation
Experience **scientifically accurate gravitational physics**:
- **Newton's Law**: F = G × (m₁ × m₂) / r² - Real gravitational forces
- **Orbital Mechanics**: Planets follow realistic elliptical orbits with proper velocities
- **Mass System**: Every object has realistic mass (stars, planets, black holes)
- **Event Horizons**: Black holes capture objects within Schwarzschild radius
- **Escape Velocity**: Objects can break free from gravitational pull
- **Tidal Forces**: Gravitational gradients near massive objects

### 🪐 Advanced Orbital Physics
- **Automatic Orbital Velocity**: v = √(G × M / r) - Calculated for stable orbits
- **Dynamic Orbits**: Planets move faster when closer to stars (Kepler's laws)
- **Elliptical Paths**: No more perfect circles - realistic orbital mechanics
- **Multi-Body Interactions**: Objects affected by multiple gravitational sources
- **Physics Toggle**: Switch between realistic physics and simple orbits

### 🎯 Visualization Tools
- **Gravity Vectors**: Yellow arrows showing force direction and magnitude
- **Orbital Paths**: Blue predicted trajectories (64 segments)
- **Real-time Forces**: See gravitational interactions as they happen
- **Debug Mode**: Perfect for learning orbital mechanics

### ⚙️ Gravity Settings
New controls in **Advanced Settings**:
- **Realistic Gravity**: Toggle physics simulation on/off
- **Gravity Quality**: Low/Medium/High precision (1-3)
- **Gravity Speed**: Adjust simulation timestep (0.001-0.1)
- **Show Gravity Vectors**: Visualize forces
- **Show Orbital Paths**: See predicted trajectories

### 📊 Performance
- **Optimized N-Body**: Efficient calculations with minimal FPS impact
- **Quality Levels**: Choose performance vs accuracy
- **Low Impact**: Only -2% to -7% FPS depending on quality
- **Optional Visuals**: Disable visualizations for best performance

## Features

### Galaxy System
- **Spiral Galaxies**: Realistic spiral galaxies with 2-6 spiral arms
- **Galaxy Branches**: Procedurally generated spiral arms with star clouds
- **Hierarchical Loading**: Galaxies load their stars only when you approach them (saves FPS!)
- **Dynamic LOD**: Distant galaxies appear as glowing spirals, close galaxies show individual stars
- **Supermassive Black Holes**: Every galaxy has a black hole at its center
- **Black Hole Rendering**: 
  - Event horizon (pure black sphere)
  - Accretion disk (orange/yellow swirling matter)
  - Gravitational lensing effect (bright ring)
- **Galaxy Colors**: Blue-white, yellow-white, and red-white galaxy variations
- **Massive Scale**: Galaxies span 2000-5000 units in radius

### Interactive Info System
- **Click on Galaxies**: View branch count, star count, radius, and black hole info
- **Click on Stars**: See star type, radius, and planet counts by type
- **Click on Black Holes**: View event horizon size, accretion disk radius, and location
- **Planet Statistics**: Rocky, Gas, and Ice planet counts for each star
- **Real-time UI**: Info menu follows your clicks and updates dynamically

### Realistic 3D Stars
- **3D Sphere Rendering**: Stars appear as realistic spheres with proper lighting and shading
- **Glowing Corona**: Multi-layered atmospheric glow around each star
- **Surface Texture**: Random variations simulating solar activity and surface detail
- **Bright Core**: White-hot centers for larger stars
- **Solar Prominences**: Flame-like protrusions extending from larger stars
- **Massive Scale**: Stars range from 10-70 units in radius, creating epic celestial bodies
- **Three Star Types**:
  - White stars (45%) - Medium to huge, bright white (10-50 radius)
  - Yellow stars (40%) - Sun-like, golden yellow (15-60 radius)
  - Red giants (15%) - Massive, deep red (30-70 radius)

### Planets with Realistic Physics
- **N-Body Gravity**: Planets affected by gravitational forces from stars and black holes
- **Realistic Masses**: Mass calculated from size and composition (rocky/gas/ice)
- **Orbital Mechanics**: 
  - Automatic orbital velocity calculation: v = √(G × M / r)
  - Elliptical orbits from physics simulation
  - Varying speeds based on distance (Kepler's laws)
  - Can escape or be captured by massive objects
- **Three Planet Categories**:
  - **Rocky Planets**: Mercury, Venus, Mars, Earth (density 3.9-5.5)
  - **Gas Giants**: Jupiter, Saturn, Purple, Green (density 0.7-1.3)
  - **Ice Planets**: Blue Ice, Cyan Ice, White Ice, Purple Ice (density 0.9-1.0) - Frozen worlds with icy surfaces
- **Temperature-Based Coloring**: 
  - Planets close to their star glow red-hot or white-hot
  - Planets far from their star appear blue-white and icy
  - Medium distance planets retain their natural colors
- **Five Size Categories**: Tiny, Small, Normal, Giant, Super Giant (20-450 radius)
- **Rare Earth**: Earth-like planets are extremely rare (0.1% chance!)
- **Dynamic Systems**: 25% of stars have 1-4 orbiting planets
- **Physics Toggle**: Choose between realistic gravity or simple circular orbits

### Camera System
- **Free-look Mouse Control**: Move your mouse to look around in any direction
- **6-Axis Movement**: Full freedom to navigate through 3D space
- **Speed Boost**: Hold Shift for faster movement
- **Smooth Rotation**: Responsive camera controls with adjustable sensitivity

### Dynamic Universe
- **Hierarchical Rendering**: Galaxies → Stars → Planets (performance optimized!)
- **Smart Loading**: Stars only load when you approach a galaxy (within 8000 units)
- **Auto Unloading**: Stars unload when you move away (beyond 12000 units)
- **Depth-based Rendering**: Objects fade with distance for realistic depth perception
- **Depth Buffer Occlusion**: Objects behind other objects are properly hidden
- **Massive Scale**: Universe spans 60000x40000x100000 units
- **30 Galaxies**: Each with 300-800 stars
- **Optimized Culling**: Only visible objects are rendered for better performance

## Build Versions

This project supports two build configurations:

### DEV Version (Testing)
- **Current Mode**: Active by default
- **Features**:
  - Debug information displayed (star count, FPS, speed)
  - Massive spawn area (6000x4000x10000 units)
  - More stars (2000 initial, up to 5000 max)
  - Performance stats available
  - Extended testing parameters

### PUBLIC Version (Release)
- **Features**:
  - Clean UI with minimal info
  - Large spawn area (4000x3000x8000 units)
  - Balanced star count (1000 initial, up to 3000 max)
  - Production-ready settings

## Switching Between Versions

To switch from DEV to PUBLIC version:

1. Open `Config.cs`
2. Change line 8 from:
   ```csharp
   public const bool IS_DEV_BUILD = true;
   ```
   to:
   ```csharp
   public const bool IS_DEV_BUILD = false;
   ```
3. Rebuild the project

## Controls

### Main Menu
- **Mouse**: Hover over buttons to select
- **Arrow Up/Down**: Navigate between PLAY and EXIT
- **Enter or Left Click**: Confirm selection
- **PLAY**: Start the simulation
- **EXIT**: Quit the application (only way to exit)

### In-Game Controls

#### Camera Movement
- **W**: Move forward (into space)
- **S**: Move backward
- **A**: Strafe left
- **D**: Strafe right
- **Arrow Up**: Move up
- **Arrow Down**: Move down
- **Arrow Left**: Strafe left
- **Arrow Right**: Strafe right

#### Camera Look
- **Mouse Movement**: Look around in any direction (always active)
- **Mouse Wheel (Molette)**: Scroll up to increase speed, scroll down to decrease speed (1-50 range)

#### Interaction
- **Left Click**: Click on galaxies, stars, or black holes to view info
- **Right Click or Escape**: Close info menu

#### Other
- **Tab**: Toggle mouse look on/off (show cursor to click on objects, hide cursor for camera control)
- **Left Shift**: Hold to move 2x faster (multiplies current speed)
- **Right Shift (Maj Droit)**: Return to main menu
- **Print Screen**: Take a screenshot (saved to Screenshots folder)

## Running the Project

### Prerequisites
- .NET 6.0 or higher
- MonoGame Framework

### Setup and Run

First, restore packages:
```bash
dotnet restore
```

Then build and run:
```bash
dotnet build
dotnet run
```

The game will launch in fullscreen mode at your native resolution.

## Technical Details

### Rendering
- **Engine**: MonoGame Framework
- **Graphics**: Custom pixel-based rendering with procedural star generation
- **Display**: Fullscreen, native resolution
- **Star Rendering**: Multi-layer corona, 3D sphere shading, procedural surface detail

### Performance
- Optimized depth sorting for stars and planets
- Depth buffer for proper occlusion culling
- Frustum culling for off-screen objects
- Dynamic star spawning and despawning
- Configurable limits (1000-5000 stars, hundreds of planets depending on build)
- Real-time orbital calculations

### Architecture
- `UniverseGame.cs`: Main game loop, rendering, and click handling
- `Galaxy.cs`: Galaxy properties, spiral arm generation, and star loading
- `GalaxySpawner.cs`: Galaxy generation and hierarchical loading system
- `GalaxyRenderer.cs`: Galaxy and black hole rendering
- `BlackHole.cs`: Black hole properties and projection
- `Star.cs`: Star properties, types, and projection
- `StarRenderer.cs`: Advanced 3D star rendering with coronas and flares
- `Planet.cs`: Planet properties, types, and orbital mechanics
- `PlanetRenderer.cs`: Planet rendering with atmospheric effects
- `PlanetSpawner.cs`: Planet generation and orbital system management
- `InfoMenu.cs`: Interactive info menu for clicked objects
- `Camera.cs`: 3D camera with rotation and movement
- `MainMenu.cs`: Menu system with keyboard and mouse support
- `Config.cs`: Build configuration and parameters

## Customization

You can adjust various parameters in `Config.cs`:
- Star count limits
- Spawn area dimensions
- Star spawn rate
- Debug information display
- And more...

## 📊 Performance Comparison

| Detail Level | FPS | GPU Usage | Best For |
|--------------|-----|-----------|----------|
| 🌑 LOW | 200+ | 10% | Low-end PCs, fast simulation |
| ☀️ NORMAL | 60+ | 30% | Daily use, balanced |
| 🌟 OPTIMIZED | 45+ | 50% | Mid-range PCs, smooth visuals |
| 🌞 HIGH | 30+ | 70% | Good PCs, beautiful graphics |
| 🌋 MAX | 20+ | 90%+ | Gaming PCs, stunning visuals |

## ⚙️ Quick Settings Guide

### Access Settings
**Main Menu → Settings → Advanced Settings**

### Recommended Configurations

#### Low-End PC
```
Preset: Performance
Detail Level: LOW
Max Visible Stars: 100-200
```

#### Mid-Range PC
```
Preset: Balanced
Detail Level: NORMAL or OPTIMIZED
Max Visible Stars: 300-500
```

#### High-End PC
```
Preset: Quality
Detail Level: HIGH or MAX
Max Visible Stars: 800-1000
```

## 📁 Documentation

- **Public Docs** (in `docs/public/`):
  - `GRAVITY_UPDATE_README.md` - Complete gravity system guide
  - `GRAVITY_QUICK_START.md` - Quick start for gravity features
  - `RELEASE_NOTES_0.1.3.md` - Full release notes
  - `VERSION_0.1.2_RELEASE.md` - Previous release notes
  - `README_v0.1.2.md` - Previous version guide
  - `QUICK_REFERENCE.md` - Quick reference card

- **Internal Docs** (in `docs/private/`):
  - `WHAT_WAS_BUILT.md` - Development summary
  - `VERSION_0.1.3_SUMMARY.md` - Technical summary
  - Technical documentation
  - Development notes
  - Change summaries

## 🔮 Roadmap

### v0.1.6
- Comet trails
- Nebulae clouds
- Star clusters

### v0.2.0
- Multi-body orbital resonances
- Binary star systems
- Lagrange points
- Gravitational slingshots

### v0.3.0
- Mission system
- Rare planet discovery
- Exploration statistics
- VR mode support
